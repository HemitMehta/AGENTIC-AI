"""
models/requests.py

Pydantic request models for verification service endpoints.
"""

from pydantic import BaseModel, Field
from typing import Optional


class NonceRequest(BaseModel):
    """Request to generate a nonce."""
    
    verifierDID: str = Field(..., description="DID of the verifier requesting the nonce")
    purpose: str = Field(..., description="Purpose of the nonce (e.g., 'presentation_submission')")


class PresentationRequest(BaseModel):
    """Request to verify a VP (Verifiable Presentation)."""
    
    vp_jwt: str = Field(..., description="Signed VP JWT")
    nonce: str = Field(..., description="Nonce value used in the presentation")
    verifierDID: str = Field(..., description="DID of the verifier")


class CredentialRequest(BaseModel):
    """Request to verify a standalone VC (without VP wrapper)."""
    
    vc_jwt: str = Field(..., description="Signed VC JWT (without VP wrapper)")
