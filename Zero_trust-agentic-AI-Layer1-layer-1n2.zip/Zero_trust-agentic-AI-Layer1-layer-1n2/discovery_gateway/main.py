"""
main.py -- Discovery Gateway (Module 5, Shared)
Port: 8012

Responsibilities:
  Thin orchestrator, no business logic of its own beyond ranking:
    1. Call Discovery Trust Policy Service (Module 3, 8010) -- reject early
       if the requested registry/provider/capability domain isn't trusted.
    2. Call ANS Resolver Service (Module 2, 8009) -- get verified, signed
       candidate agent records for the requested capability.
    3. Call Reputation Service (Module 4, 8011) -- enrich each candidate
       with its aggregated reputation score.
    4. Rank candidates (baseline: reputation score, since Capability Match /
       Intent Match / Trust Prediction / Context are AIADTE Phase 2
       extensions not yet built) and select the best one.
    5. Sign the final unified response via Layer 1's kms (8001) and return it.

This module has no persistent storage and depends only on Modules 2, 3, 4,
plus kms directly for the final response signature. It is intentionally
built last, once Modules 1-4 are individually stable, per the team's build
order -- it is mostly wiring.

IMPORTANT -- contract assumption:
  The kms /sign contract below is ASSUMED, matching the same assumption
  documented in module2_ans_resolver/main.py. Confirm against the actual
  Layer 1 kms service source before relying on this in a real integration
  test.
"""

import os
import logging
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException

from models import DiscoveryRequest, DiscoveryResponse, CandidateSummary

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("discovery_gateway")

# ---------------------------------------------------------------------------
# Config -- downstream Layer 2 modules + Layer 1 kms
# ---------------------------------------------------------------------------
TRUST_POLICY_URL = os.getenv("TRUST_POLICY_URL", "http://discovery_trust_policy_service:8010")
ANS_RESOLVER_URL = os.getenv("ANS_RESOLVER_URL", "http://ans_resolver_service:8009")
REPUTATION_SERVICE_URL = os.getenv("REPUTATION_SERVICE_URL", "http://reputation_service:8011")
KMS_URL = os.getenv("KMS_URL", "http://kms:8001")
SIGNING_KEY_ID = os.getenv("GATEWAY_SIGNING_KEY_ID", "discovery-gateway-signing-key")

REQUEST_TIMEOUT_SECONDS = float(os.getenv("DOWNSTREAM_TIMEOUT_SECONDS", "5"))

app = FastAPI(
    title="Discovery Gateway",
    description="Layer 2 / Module 5 -- unified discovery + trust orchestration entry point",
    version="0.1.0",
)


# ---------------------------------------------------------------------------
# Step 1 -- Discovery Trust Policy Service
# ---------------------------------------------------------------------------
async def _check_trust(req: DiscoveryRequest) -> tuple[bool, list[str]]:
    url = f"{TRUST_POLICY_URL}/check"
    body = {"registryId": req.registryId, "provider": req.provider, "capability": req.capability}
    try:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as client:
            resp = await client.post(url, json=body)
        resp.raise_for_status()
        data = resp.json()
        return bool(data.get("trusted", False)), data.get("reasons", [])
    except httpx.RequestError as exc:
        logger.error("Discovery Trust Policy Service unreachable at %s: %s", url, exc)
        # Fail closed: if we can't confirm the source is trusted, reject.
        return False, [f"trust policy service unreachable: {exc}"]


# ---------------------------------------------------------------------------
# Step 2 -- ANS Resolver
# ---------------------------------------------------------------------------
async def _resolve_candidates(req: DiscoveryRequest) -> list[dict]:
    url = f"{ANS_RESOLVER_URL}/resolveByCapability"
    body = {
        "capability": req.capability,
        "provider": req.provider,
        "protocol": req.protocol,
        "versionPrefix": req.versionPrefix,
        "requiredAttestations": req.requiredAttestations,
        "maxResults": req.maxCandidates,
    }
    try:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as client:
            resp = await client.post(url, json=body)
        resp.raise_for_status()
        return resp.json().get("resolvedAgents", [])
    except httpx.RequestError as exc:
        logger.error("ANS Resolver unreachable at %s: %s", url, exc)
        raise HTTPException(status_code=502, detail=f"ANS Resolver unreachable: {exc}") from exc


# ---------------------------------------------------------------------------
# Step 3 -- Reputation Service
# ---------------------------------------------------------------------------
async def _get_reputation(agent_did: str) -> tuple[float, int]:
    url = f"{REPUTATION_SERVICE_URL}/reputation/{agent_did}"
    try:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as client:
            resp = await client.get(url)
        resp.raise_for_status()
        data = resp.json()
        return float(data.get("score", 0.0)), int(data.get("sampleSize", 0))
    except httpx.RequestError as exc:
        logger.warning("Reputation Service unreachable at %s, defaulting to score 0: %s", url, exc)
        return 0.0, 0


# ---------------------------------------------------------------------------
# Step 5 -- sign the final response
# ---------------------------------------------------------------------------
async def _sign_response(payload: dict) -> Optional[str]:
    """
    Real Layer 1 contract (kms_service.py legacy route, deprecated but
    still served): POST /sign { "key_id": ..., "payload": <base64 bytes> }
    -> { "signature": ... }. Payload must be JSON-serialised + base64
    encoded first -- see the identical fix in
    ans_resolver_service/main.py::_sign_record for the full rationale.
    """
    import base64
    import json as _json

    url = f"{KMS_URL}/sign"
    payload_b64 = base64.b64encode(_json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).decode("ascii")
    try:
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SECONDS) as client:
            resp = await client.post(url, json={"key_id": SIGNING_KEY_ID, "payload": payload_b64})
        resp.raise_for_status()
        return resp.json().get("signature")
    except httpx.RequestError as exc:
        logger.warning("kms unreachable at %s, returning unsigned gateway response: %s", url, exc)
        return None
    except httpx.HTTPStatusError as exc:
        logger.warning("kms rejected the sign request (HTTP %s) -- has %s been generated via POST /keys/generate? %s",
                        exc.response.status_code, SIGNING_KEY_ID, exc.response.text)
        return None


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.get("/health")
async def health():
    return {"status": "healthy", "service": "discovery_gateway"}


# ---------------------------------------------------------------------------
# The one public endpoint
# ---------------------------------------------------------------------------
@app.post("/discover", response_model=DiscoveryResponse)
async def discover(req: DiscoveryRequest):
    # 1. Trust Policy check
    trusted, reasons = await _check_trust(req)
    if not trusted:
        logger.info("Discovery request rejected by trust policy: %s", reasons)
        return DiscoveryResponse(resolutionStatus="rejected_by_trust_policy", rejectionReasons=reasons)

    # 2. ANS Resolver query
    raw_candidates = await _resolve_candidates(req)
    if not raw_candidates:
        return DiscoveryResponse(resolutionStatus="no_matches")

    # 3. Reputation enrichment
    candidates: list[CandidateSummary] = []
    for c in raw_candidates:
        score, sample_size = await _get_reputation(c["agentDid"])
        candidates.append(
            CandidateSummary(
                ansName=c["ansName"],
                agentDid=c["agentDid"],
                serviceEndpoint=c["serviceEndpoint"],
                provider=c["provider"],
                version=c["version"],
                capability=c["capability"],
                reputationScore=score,
                reputationSampleSize=sample_size,
                ansRecordSignature=c.get("ansRecordSignature"),
            )
        )

    # 4. Rank -- baseline: highest reputation score wins, ties broken by
    #    sample size (more evidence behind the score wins). This is the
    #    Phase 1 placeholder for the AIADTE Adaptive Agent Ranking Engine,
    #    which would replace this with the full weighted formula from the
    #    architecture doc once Capability Match / Intent Match / Trust
    #    Prediction / Context components exist.
    candidates.sort(key=lambda c: (c.reputationScore, c.reputationSampleSize), reverse=True)
    best = candidates[0]

    response = DiscoveryResponse(
        resolutionStatus="success",
        selectedAgent=best.agentDid,
        endpoint=best.serviceEndpoint,
        reputation=best.reputationScore,
        capabilities=[best.capability],
        candidates=candidates,
    )

    # 5. Sign the final response
    response.gatewaySignature = await _sign_response(response.model_dump(mode="json", exclude={"gatewaySignature"}))
    return response