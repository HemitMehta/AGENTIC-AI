"""
status_list_service/services/bitstring_manager.py

Core bitstring operations: allocation, bit flipping, compression, encoding.
"""

import logging
import gzip
import base64
import uuid
from typing import Tuple

from db.connection import get_session
from db.queries.status_list_queries import (
    get_active_status_list_for_issuer,
    create_status_list,
    claim_status_list_index
)
from config import BITSTRING_SIZE_BITS, BITSTRING_SIZE_BYTES, STATUS_LIST_BASE_URL

logger = logging.getLogger(__name__)


def flip_bit(bitstring: bytes, index: int) -> bytes:
    """
    Flip a bit to 1 (revoked) at the given index.

    Big-endian per StatusList2021 spec:
    - Bit 0 is the MSB of byte 0
    - Bit indexing: byte_pos = index // 8, bit_pos = 7 - (index % 8)
    """
    ba = bytearray(bitstring)
    byte_pos = index // 8
    bit_pos = 7 - (index % 8)
    ba[byte_pos] |= (1 << bit_pos)
    return bytes(ba)


async def allocate_status_entry(issuer_did: str, vc_id: str) -> Tuple[str, int]:
    """
    Allocate a new status list entry for a VC.

    Returns: (status_list_url, bit_index)

    Algorithm:
    1. Find active status list for issuer with space available
    2. If none exists, create new one (131,072 bits)
    3. Claim next_free_index atomically
    4. Return URL and index
    """
    # FIX (combined Layer 1 + Layer 2 integration): see the identical fix
    # and full rationale in status_list_vc_builder.py -- get_session() is
    # not async; this previously wrote `await get_session()`, which is
    # exactly the error surfaced when POST /status-lists/allocate (this
    # function) was first genuinely exercised by a real vc_issuance call.
    session = get_session()

    try:
        # Check for active status list with space
        active_list = await get_active_status_list_for_issuer(session, issuer_did)

        if not active_list:
            # Create new status list
            bitstring_bytes = b'\x00' * BITSTRING_SIZE_BYTES
            result = await create_status_list(session, issuer_did, bitstring_bytes)
            status_list_id = result["id"]
            next_index = 0
        else:
            status_list_id = active_list["id"]
            next_index = active_list["next_free_index"]

        # Claim the index atomically
        claimed = await claim_status_list_index(session, status_list_id, next_index)

        if not claimed:
            # Race condition: index was already claimed
            logger.warning(f"Race condition claiming index {next_index} in {status_list_id}")
            # Retry (in production, implement exponential backoff)
            return await allocate_status_entry(issuer_did, vc_id)

        # Construct URL
        status_list_url = f"{STATUS_LIST_BASE_URL}/status-lists/{status_list_id}"

        logger.info(f"Allocated bit {next_index} in list {status_list_id} for VC {vc_id}")
        return status_list_url, next_index

    finally:
        await session.close()


def compress_and_encode_bitstring(bitstring: bytes) -> str:
    """
    GZIP compress and Base64url encode a bitstring.

    Per StatusList2021 spec: encodedList = base64url(gzip(bitstring))
    """
    compressed = gzip.compress(bitstring)
    encoded = base64.urlsafe_b64encode(compressed).decode().rstrip("=")
    return encoded


def decode_bitstring(encoded: str) -> bytes:
    """
    Reverse of compress_and_encode: decode and decompress.
    """
    # Add back padding
    padding = 4 - (len(encoded) % 4)
    if padding != 4:
        encoded += "=" * padding

    compressed = base64.urlsafe_b64decode(encoded)
    bitstring = gzip.decompress(compressed)
    return bitstring