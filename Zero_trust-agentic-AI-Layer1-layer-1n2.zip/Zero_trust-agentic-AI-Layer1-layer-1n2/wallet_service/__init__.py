"""Wallet Service package."""
