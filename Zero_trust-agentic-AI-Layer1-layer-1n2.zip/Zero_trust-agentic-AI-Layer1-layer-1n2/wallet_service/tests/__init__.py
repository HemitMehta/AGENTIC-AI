"""Tests for Wallet Service."""
