"""Cryptographic utilities."""
