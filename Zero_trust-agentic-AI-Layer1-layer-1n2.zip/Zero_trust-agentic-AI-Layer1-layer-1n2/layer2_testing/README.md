# Testing Layer 2

There are two useful ways to test Layer 2, depending on whether the real
Layer 1 services are running.

## Option A: Isolated Test

This starts a lightweight mock Layer 1 plus all five real Layer 2 modules as
local processes. It exercises the discovery flow and tears everything down
automatically.

```bash
cd layer2_testing
pip install fastapi uvicorn pydantic httpx psycopg2-binary
bash run_integration_test.sh
```

Expected output: 13 `PASS` lines and `ALL TESTS PASSED` with exit code `0`.
Logs for each process are written to `/tmp/layer2_test_logs/`.

This proves:

1. ANS registry accepts resolvable DIDs and rejects unresolvable DIDs.
2. Reputation service records feedback, issues a reputation VC, and aggregates scores.
3. ANS resolver verifies required attestations through wallet and presentation verification.
4. ANS resolver drops a candidate whose attestation is revoked.
5. Discovery gateway applies trust policy, enriches reputation, ranks, and signs the response.

## Option B: Full Stack Test

Run the actual Layer 1 and Layer 2 services together:

```bash
docker compose up --build
```

Then, in a second terminal, run the real full-stack script:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\layer2_testing\run_real_full_stack_test.ps1
```

This script creates real KMS keys, real DID documents, a real trust-anchor
issuer authorization, a real Role VC, a real wallet entry, a real VP
verification, a real ANS registration, real reputation feedback, and a real
Discovery Gateway query with `requiredAttestations = ["RoleVC"]`.

You can also test manually with a DID that exists in the real DID registry:

```bash
curl -X POST http://localhost:8008/register -H "Content-Type: application/json" -d '{
  "ansName": "acp://YourAgent.YourCapability.YourProvider.v1.0.0.prod",
  "agentDid": "did:web:your-real-registered-did",
  "capability": "YourCapability.SubDomain",
  "provider": "YourProvider",
  "version": "1.0.0",
  "serviceEndpoint": "https://your-agent.example.com/service"
}'

curl -X POST http://localhost:8011/feedback -H "Content-Type: application/json" -d '{
  "raterDid": "did:web:some-rater",
  "ratedAgentDid": "did:web:your-real-registered-did",
  "rating": 5,
  "issueVc": true
}'

curl -X POST http://localhost:8012/discover -H "Content-Type: application/json" -d '{
  "capability": "YourCapability.SubDomain"
}'
```

The real integration path validates the Layer 2 contracts with
`did_registry`, `wallet_service`, `vc_verification`, `kms`, and `vc_issuance`.
If a dependency rejects a call, check the relevant service logs; signatures may
come back `null` and attestations may come back unverified by design.

## Manual Testing

Each module exposes FastAPI docs at `/docs`, for example:

```text
http://localhost:8012/docs
```
